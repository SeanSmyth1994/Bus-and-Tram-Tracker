package com.example.bustracker.GoogleDirections;

public class EndLocation {
    public double lat;
    public double lng;
}
