package com.example.bustracker.Data;

import com.example.bustracker.Vehicle.Bus;

import com.example.bustracker.Vehicle.Departures;
import com.example.bustracker.Vehicle.Directions;
import com.example.bustracker.Vehicle.Route;
import com.example.bustracker.Vehicle.Stops;
import com.example.bustracker.GoogleDirections.googleDirections;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;


public class getJSON {

    static JSONObject jsonObject;
    static String jsonText_;


    private static String readAll(Reader rd) throws IOException {
        StringBuilder sb = new StringBuilder();
        int cp;
        while ((cp = rd.read()) != -1) {
            sb.append((char) cp);
        }
        return sb.toString();
    }

    public static Bus readJsonFromUrl(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);


            Gson gson = new GsonBuilder().serializeNulls().create();
            String gsonText = gson.toJson(json.toString());
            System.out.println(gsonText);
            Bus bus = new Gson().fromJson(String.valueOf(json.toString()), Bus.class);
            return bus;

        } finally {

        }
    }



    public static Stops readStopData(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);


            Gson gson = new GsonBuilder().serializeNulls().create();
            String gsonText = gson.toJson(json.toString());
            System.out.println(gsonText);
            Stops stops = new Gson().fromJson(String.valueOf(json.toString()), Stops.class);
            return stops;

        } finally {

        }
    }

    public static Route readRouteData(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);


            Gson gson = new GsonBuilder().serializeNulls().create();
            String gsonText = gson.toJson(json.toString());
            System.out.println(gsonText);
            Route route = new Gson().fromJson(String.valueOf(json.toString()), Route.class);
            return route;

        } finally {

        }
    }
    public static Directions readDirections(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);


            Gson gson = new GsonBuilder().serializeNulls().create();
            String gsonText = gson.toJson(json.toString());
            System.out.println(gsonText);
            Directions direction = new Gson().fromJson(String.valueOf(json.toString()), Directions.class);
            return direction;

        } finally {

        }
    }

    public static Departures readDepartures(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);


            Gson gson = new GsonBuilder().serializeNulls().create();
            String gsonText = gson.toJson(json.toString());
            System.out.println(gsonText);
            Departures departures = new Gson().fromJson(String.valueOf(json.toString()), Departures.class);
            return departures;

        } finally {

        }
    }

    public static googleDirections readGoogleDepartures(String url) throws IOException, JSONException {
        InputStream is = new URL(url).openStream();
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
            String jsonText = readAll(rd);
            JSONObject json = new JSONObject(jsonText);


            Gson gson = new GsonBuilder().serializeNulls().create();
            String gsonText = gson.toJson(json.toString());
            System.out.println(gsonText);
            googleDirections departures = new Gson().fromJson(String.valueOf(json.toString()), googleDirections.class);
            return departures;

        } finally {

        }
    }

    public static void deSerializeJSON(){





    }
}



