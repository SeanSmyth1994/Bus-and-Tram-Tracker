package com.example.bustracker.Vehicle;

public abstract class Vehicle {
}
