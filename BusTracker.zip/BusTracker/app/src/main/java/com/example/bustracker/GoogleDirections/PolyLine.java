package com.example.bustracker.GoogleDirections;

public class PolyLine {
    String points;
    public PolyLine(String points){
        this.points = points;
    }

    public String getPoints() {
        return points;
    }
}
