package com.example.bustracker.GoogleDirections;

public class Distance {
    String text;
    int value;
}
