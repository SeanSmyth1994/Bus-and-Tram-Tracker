package com.example.bustracker.GoogleDirections;

public class Distance2 {
    String text;
    int value;
}
