package com.example.bustracker.GoogleDirections;

public class Bounds {
    NorthEast northEast;
    SouthWest southWest;
}
