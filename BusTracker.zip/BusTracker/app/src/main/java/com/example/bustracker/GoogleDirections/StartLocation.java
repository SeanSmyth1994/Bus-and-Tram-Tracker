package com.example.bustracker.GoogleDirections;

public class StartLocation {
     double lat;
     double lng;
}
