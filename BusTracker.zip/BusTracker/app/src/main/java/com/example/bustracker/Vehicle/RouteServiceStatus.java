package com.example.bustracker.Vehicle;

public class RouteServiceStatus {
    String description;
    String timestamp;

    public RouteServiceStatus(){}
}
