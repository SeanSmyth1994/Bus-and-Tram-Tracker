package com.example.bustracker.Activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;

import com.example.bustracker.Data.GenerateSignature;
import com.example.bustracker.Data.getJSON;
import com.example.bustracker.R;
import com.example.bustracker.Vehicle.Departures;
import com.example.bustracker.Vehicle.Directions;
import com.example.bustracker.Vehicle.Route;
import com.example.bustracker.Vehicle.Stops;
import com.example.bustracker.GoogleDirections.googleDirections;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.PolyUtil;
import com.mancj.materialsearchbar.MaterialSearchBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.Navigation;

import android.os.StrictMode;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.json.JSONException;

import java.io.IOException;
import java.util.Date;
import java.util.List;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private Location mLastKnownLocation;
    private Location currentLocation;
    private LocationCallback locationCallback;
    private MaterialSearchBar searchBar;
    private View mapView;
    private GenerateSignature generateSignature_;
    private final int route_type = 2;
    private final int max_results = 30;
    private final int max_distance = 2000;
    private DrawerLayout drawer;
    Stops stopsLocation;
    private String search;

    ToggleButton directionSwitch;

    private int direction;

    private int defaultZoom = 14;

    private int direction_id;
    private Route route;
    private Polyline polyline;

    private Marker marker;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_map);
        searchBar = (MaterialSearchBar) findViewById(R.id.searchBar);
        searchBar.setHint("Route Number");




        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(MapActivity.this);


        generateSignature_ = new GenerateSignature();


        mapView = mapFragment.getView();
        Switch toggle = (Switch) findViewById(R.id.directionSwitch);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    direction_id = 1;

                } else {
                    // The toggle is disabled
                    direction_id = 0;
                }
            }
        });

        ToggleButton toggleButton = (ToggleButton) findViewById(R.id.toggleButton);

        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    // get all stop info and make markers
//                    for(Route r : route.getRouteList())
//                        Marker routeMarker = mMap.addMarker(new MarkerOptions()
//                        .position(r.))

                }else{

                }
            }
        });

        View navigation = (View) findViewById(R.id.navigation);

        searchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {

            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                search = text.toString();
                try {
                    getSearchResults(text.toString(), direction_id);
                    // pop up with menu


                }catch(Exception e){
                    Toast.makeText(MapActivity.this, "Invalid Route Number",Toast.LENGTH_SHORT).show();

                }
                searchBar.disableSearch();

            }

            @Override
            public void onButtonClicked(int buttonCode) {
                if(buttonCode == MaterialSearchBar.BUTTON_NAVIGATION){



                }else if(buttonCode == MaterialSearchBar.BUTTON_BACK){
                    searchBar.disableSearch();
                }

            }
        });



    }


    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);


        if(mapView != null && mapView.findViewById(Integer.parseInt("1")) != null){
            View locationButton = ((View) mapView.findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) locationButton.getLayoutParams();
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
            layoutParams.setMargins(0,0,40,180);


        }


        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);

        SettingsClient settingsClient = LocationServices.getSettingsClient(MapActivity.this);
        Task<LocationSettingsResponse> task = settingsClient.checkLocationSettings(builder.build());

        task.addOnSuccessListener(MapActivity.this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                getDeviceLocation();
            }
        });
        task.addOnFailureListener(MapActivity.this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if(e instanceof ResolvableApiException){
                    ResolvableApiException resolvableApiException  = (ResolvableApiException) e;
                    try{
                        resolvableApiException.startResolutionForResult(MapActivity.this,51);
                    }catch(IntentSender.SendIntentException e1){
                        e1.printStackTrace();
                    }

                }

            }
        });

        mMap.setTrafficEnabled(true);


    }




    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 51) {
            if (resultCode == RESULT_OK) {
                getDeviceLocation();
            }
        }
    }
    @SuppressLint("MissingPermission")
    private void getDeviceLocation(){
        mFusedLocationProviderClient.getLastLocation()
                .addOnCompleteListener(new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if(task.isSuccessful()){
                            mLastKnownLocation = task.getResult();
                            currentLocation = task.getResult();
                            if(mLastKnownLocation != null){
                                String lat = Double.toString(mLastKnownLocation.getLatitude());
                                String lon = Double.toString(currentLocation.getLongitude());

                                // will parse this into bus class file ------//
                                GenerateSignature generateSignature = new GenerateSignature();
                                final String url = generateSignature_.generateCompleteURLWithSignature("5057f779-eb69-43d0-a897-106c88468536", "/v3/stops/location/" + lat + "," + lon + "?route_types=" + route_type + "&max_results=" + max_results + "&max_distance=" + max_distance + "&stop_disruptions=true", 3001241);

                                try {
                                    stopsLocation = getJSON.readStopData(url);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mLastKnownLocation.getLatitude(),mLastKnownLocation.getLongitude()), defaultZoom));

                            }else{
                                final LocationRequest locationRequest = LocationRequest.create();
                                locationRequest.setInterval(10000);
                                locationRequest.setFastestInterval(5000);
                                locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

                                locationCallback = new LocationCallback(){
                                    @Override
                                    public void onLocationResult(LocationResult locationResult){
                                        super.onLocationResult(locationResult);
                                        if(locationResult == null){
                                            return;
                                        }
                                        mLastKnownLocation = locationResult.getLastLocation();
                                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mLastKnownLocation.getLatitude(),mLastKnownLocation.getLongitude()), defaultZoom));
                                        mFusedLocationProviderClient.removeLocationUpdates(locationCallback);

                                    }
                                };
                                mFusedLocationProviderClient.requestLocationUpdates(locationRequest,locationCallback,null);


                            }
                        } else{
                            Toast.makeText(MapActivity.this, "unable to get last Location", Toast.LENGTH_SHORT).show();
                        }
                    }
                });




    }
    // Search refers to the route number
    // parse out all logic to another class
    public void getSearchResults(String search, int direction){

        if(marker != null){
            mMap.clear();
        }


        try {
            String getRouteNumber = generateSignature_.generateCompleteURLWithSignature("5057f779-eb69-43d0-a897-106c88468536", "/v3/routes?route_types=" + route_type +"&route_name="+search, 3001241);
            route = getJSON.readRouteData(getRouteNumber);
          
            //from route id we can get a whole bunch of stuff
            //need directions to get whether or not they are going to the city or not
            // need departures to relate back to the stop id we got before to then
            String getDirections = generateSignature_.generateCompleteURLWithSignature("5057f779-eb69-43d0-a897-106c88468536","/v3/directions/route/"+route.getRouteId(),3001241);

            Directions directions = getJSON.readDirections(getDirections);

            int stop_id = Integer.MIN_VALUE;
            double distance;

            if(direction == 1){
                direction_id = directions.getDirectionId2();
                System.out.println(direction_id);
            }
            if(direction == 0){
                directions.getDirectionId2();
                direction_id = directions.getDirectionid1();
                System.out.println(direction_id);
            }

            //get stop id that matches the stop ids based on location

            String getRouteStopData = generateSignature_.generateCompleteURLWithSignature("5057f779-eb69-43d0-a897-106c88468536","/v3/stops/route/"+route.getRouteId()+"/route_type/"+ route_type+"?direction_id="+direction_id,3001241);
            Stops stopsByRoute = getJSON.readStopData(getRouteStopData);
            boolean found = false;
            double lat = 0;
            double lon = 0;

            // if its found or the location stops is not empty
                for(Stops sLocation : stopsLocation.stops){
                    if(found == true){
                        stop_id = sLocation.getStop_id();
                        break;
                    }
                    for(Stops sByRoute : stopsByRoute.stops){
                        if(sLocation.getStop_id() == sByRoute.getStop_id()
                        && sLocation.getStopSequence() == sByRoute.getStopSequence()){
                            marker = mMap.addMarker(new MarkerOptions().position(
                                    new LatLng(sLocation.getStop_latitude(), sLocation.getStop_longitude()))
                                    .title(sByRoute.getStop_name()));
                            lat = sLocation.getStop_latitude();
                            lon = sLocation.getStop_longitude();
                            found = true;
                        }
                     }

                }if(stop_id == Integer.MIN_VALUE){
                Toast.makeText(MapActivity.this, "Couldn't Find Close Stop",Toast.LENGTH_SHORT).show();
            } else {
                // find closest departure that matches criteria
                String getDepartures = generateSignature_.generateCompleteURLWithSignature("5057f779-eb69-43d0-a897-106c88468536", "/v3/departures/route_type/" + route_type + "/stop/" + stop_id + "/route/" + route.getRouteId() +"?direction_id=" +direction_id + "&look_backwards=false&max_results=5" , 3001241);
                Departures departures = getJSON.readDepartures(getDepartures);

                // parse into new method for logic on the pattern
                getGoogleDirections(currentLocation.getLatitude(),currentLocation.getLongitude(),
                        lat, lon, departures);
                //now have time until next departure and can parse into new method to get directions
            }

           //

        } catch (JSONException e) {
            //Toast.makeText(MapActivity.this, "Invalid Route Number",Toast.LENGTH_SHORT).show();
        } catch (IOException f){

        }




    }
    // method will use googles direction api in order to see how long it will take
    // to walk to a stop, the if the time < then estimated time it will tell user to go
    // for the next bus.
    // alon alon -> a stands for arrival destination
    // dlat dlon --> o stands for origin dest
    public void getGoogleDirections(double oLat, double oLon, double aLat, double aLon, Departures departures){
            System.out.println(oLat + " " + oLon);
            String request = "https://maps.googleapis.com/maps/api/directions/json?" +
                    "origin="+oLat + "," + oLon + "&destination=" + aLat + "," + aLon +
                    "&mode=walking&key=AIzaSyCSRUY-53Lu2q85W_edxPxEFPaZ2aunr0o";
            System.out.println(request);



            try {
                googleDirections directions = getJSON.readGoogleDepartures(request);
                List<LatLng> allPoints = PolyUtil.decode(directions.routes.get(0).overview_polyline.getPoints());
                System.out.println("...");
                polyline = mMap.addPolyline(new PolylineOptions()
                        .width(10)
                        .color(Color.CYAN)
                        .addAll(allPoints)
                        .clickable(true));


            }catch(Exception e){

            }

    }
    // will show when user clicks the toggle button, this should allow a user to see if a bus has
    // arrived at a stop...hopefullu
    public void getPattern(){

    }




}
