package com.example.bustracker.GoogleDirections;

public class Duration {
    String text;
    int value;
}
