package com.example.bustracker.Vehicle;

public class Patterns {
    // Load up same lists

}
