package com.example.bustracker.GoogleDirections;

import java.util.List;

public class GoogleRoute {

    public Bounds bounds;
    public String copyrights;
    public List<Leg> legs;
    public OverviewPolyLine overview_polyline;
    public String summary;
    public List<Object> warnings;
    public List<Object> waypoint_order;
}

