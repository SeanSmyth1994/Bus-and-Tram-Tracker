package com.example.bustracker.GoogleDirections;

public class OverviewPolyLine {
    private String points;
    public OverviewPolyLine(String points){
        this.points = points;
    }

    public String getPoints() {
        return points;
    }
}
