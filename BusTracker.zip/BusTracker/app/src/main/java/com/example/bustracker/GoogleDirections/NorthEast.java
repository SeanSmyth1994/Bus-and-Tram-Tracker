package com.example.bustracker.GoogleDirections;

public class NorthEast {

        public double lat;
        public double lng;

}
