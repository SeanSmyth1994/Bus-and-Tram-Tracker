package com.example.bustracker.GoogleDirections;

public class SouthWest {
    public double lat;
    public double lng;
}
