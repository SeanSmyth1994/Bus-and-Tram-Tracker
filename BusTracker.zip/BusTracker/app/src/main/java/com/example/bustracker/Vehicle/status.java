package com.example.bustracker.Vehicle;

public class status {


        private String version;
        private int health;

  public status(){}

}
