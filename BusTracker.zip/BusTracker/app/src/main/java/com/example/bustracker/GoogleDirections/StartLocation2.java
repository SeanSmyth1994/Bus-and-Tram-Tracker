package com.example.bustracker.GoogleDirections;

public class StartLocation2 {
    public double lat;
    public double lng;
}
