package com.example.bustracker.GoogleDirections;

public class Duration2 {
    String text;
    int value;
}
