package com.example.bustracker.Vehicle;

import android.location.Location;
import android.os.StrictMode;

import com.example.bustracker.Activities.MapActivity;
import com.example.bustracker.Data.GenerateSignature;
import com.example.bustracker.Data.getJSON;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class Bus extends Vehicle {

    final private int route_type = 2;




    public Bus(){

    }












    // get stop data

    // get route data

    // get time to stop




}
