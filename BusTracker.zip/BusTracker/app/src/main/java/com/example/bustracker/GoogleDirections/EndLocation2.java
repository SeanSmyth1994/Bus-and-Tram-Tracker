package com.example.bustracker.GoogleDirections;

public class EndLocation2 {
    public double lat;
    public double lng;
}
