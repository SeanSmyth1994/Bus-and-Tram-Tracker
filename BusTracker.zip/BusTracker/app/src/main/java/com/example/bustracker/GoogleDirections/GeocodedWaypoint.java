package com.example.bustracker.GoogleDirections;

import java.util.List;

public class GeocodedWaypoint {
    public String geocoder_status;
    public String place_id;
    public List<String> types;


}
